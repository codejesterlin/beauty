<?php

$username = $_POST["username"];
$password = $_POST["password"];


if($username == "beauty" && $password = "123qweasd")
{
	header('Location: admin.html');
}


 ?>